#include "traveler.h"

Traveler::Traveler(){
    current_castle = 0;
    health = 100;
    treasure = 0;
}
