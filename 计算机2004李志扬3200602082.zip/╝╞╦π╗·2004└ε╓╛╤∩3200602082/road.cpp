#include "road.h"

Road::Road()
{

}

Road::Road(int _start,int _end,int _danger){
    start = _start;
    end = _end;
    danger = _danger;
}
