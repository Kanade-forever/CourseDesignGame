#ifndef TRAVELER_H
#define TRAVELER_H
#include"castle.h"

class Traveler
{
public:
    Traveler();
    int current_castle;
    int health;
    int treasure;
};

#endif // TRAVELER_H
